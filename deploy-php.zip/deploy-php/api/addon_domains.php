<?php
// api/addon_domains.php
// Handles /api/addon-domains

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);
$id = isset($_GET['id']) ? $_GET['id'] : null;

if (!$id && preg_match('/\/api\/addon-domains\/(\d+)/', $_SERVER['REQUEST_URI'], $matches)) {
    $id = $matches[1];
}

if ($method === 'GET') {
    // Select name as title for frontend compatibility (Admin uses title, Generator uses name)
    // Also alias id as dbId because Frontend uses row.dbId for actions
    $stmt = $pdo->query("SELECT *, id as dbId, name as title FROM domain ORDER BY addedAt DESC");
    echo json_encode($stmt->fetchAll());
    exit;
}

if ($method === 'POST') {
    $name = $input['domain'] ?? $input['name']; // Accept 'domain' from frontend or 'name' fallback
    // subdomain logic? Using 'name' for full domain usually.
    
    try {
        $stmt = $pdo->prepare("INSERT INTO domain (`name`, `status`, `ssl`, `addedAt`) VALUES (?, 'Active', 'Active', NOW())");
        $stmt->execute([$name]);
        echo json_encode(["success" => true, "id" => $pdo->lastInsertId()]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["error" => $e->getMessage()]);
    }
    exit;
}

if ($method === 'DELETE' && $id) {
    try {
        $stmt = $pdo->prepare("DELETE FROM domain WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(["success" => true]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["error" => $e->getMessage()]);
    }
    exit;
}
?>
