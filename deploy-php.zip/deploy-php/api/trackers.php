<?php
// api/trackers.php
// Handles /api/trackers

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);
$id = isset($_GET['id']) ? $_GET['id'] : null; // Parsing params logic might need adjustment if using /api/trackers/:id

// Helper to parse ID from path if not in GET
// Request URI: /api/trackers/123
if (!$id && preg_match('/\/api\/trackers\/(\d+)$/', $_SERVER['REQUEST_URI'], $matches)) {
    $id = $matches[1];
}

// 0. SPECIAL ROUTES

// Verify Password
if (strpos($_SERVER['REQUEST_URI'], '/api/trackers/verify-password') !== false && $method === 'POST') {
    $slug = $input['slug'] ?? '';
    $password = $input['password'] ?? '';

    $stmt = $pdo->prepare("SELECT password FROM tracker WHERE slug = ?");
    $stmt->execute([$slug]);
    $tracker = $stmt->fetch();

    if (!$tracker) {
        http_response_code(404);
        echo json_encode(["error" => "Tracker not found"]);
        exit;
    }

    // Direct comparison (since we stored plain text in creating, 
    // ideally use password_verify if hashed, but based on context user used '123' plain)
    if ((string)$tracker['password'] === (string)$password) {
        echo json_encode(["success" => true]);
    } else {
        http_response_code(401);
        echo json_encode(["error" => "Incorrect password"]);
    }
    exit;
}

// Get by Slug (for Auth Guard)
if (preg_match('/\/api\/trackers\/slug\/(.+)/', $_SERVER['REQUEST_URI'], $matches) && $method === 'GET') {
    $slug = $matches[1];
    $stmt = $pdo->prepare("SELECT id, name, team, password FROM tracker WHERE slug = ?");
    $stmt->execute([$slug]);
    $tracker = $stmt->fetch();

    if ($tracker) {
        echo json_encode([
            "id" => $tracker['id'],
            "name" => $tracker['name'],
            "team" => $tracker['team'],
            "hasPassword" => !empty($tracker['password'])
        ]);
    } else {
        http_response_code(404);
        echo json_encode(["error" => "Tracker not found"]);
    }
    exit;
}

// 1. GET Trackers
if ($method === 'GET') {
    if ($id) {
        $stmt = $pdo->prepare("SELECT * FROM tracker WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode($stmt->fetch());
    } else {
        $stmt = $pdo->query("SELECT * FROM tracker ORDER BY createdAt DESC");
        echo json_encode($stmt->fetchAll());
    }
    exit;
}

// 2. CREATE Tracker
if ($method === 'POST') {
    $name = $input['name'] ?? '';
    $slug = $input['slug'] ?? '';
    $team = $input['team'] ?? 'ADMIN';
    $password = $input['password'] ?? null;

    if (empty($name) || empty($slug)) {
        http_response_code(400);
        echo json_encode(["error" => "Name and slug are required"]);
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO tracker (name, slug, team, password, targetUrl, createdAt) VALUES (?, ?, ?, ?, '', NOW())");
        $stmt->execute([$name, $slug, $team, $password]);
        echo json_encode(["success" => true, "id" => $pdo->lastInsertId()]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["error" => $e->getMessage()]);
    }
    exit;
}

// 3. UPDATE tracker
if ($method === 'PUT' && $id) {
    $name = $input['name'];
    $slug = $input['slug'];
    $targetUrl = $input['targetUrl'];
    
    try {
        $stmt = $pdo->prepare("UPDATE tracker SET name = ?, slug = ?, targetUrl = ? WHERE id = ?");
        $stmt->execute([$name, $slug, $targetUrl, $id]);
        echo json_encode(["success" => true]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["error" => $e->getMessage()]);
    }
    exit;
}

// 4. DELETE Tracker (Cascade)
if ($method === 'DELETE' && $id) {
    try {
        $pdo->beginTransaction();

        // 1. Delete Clicks associated with Links of this Tracker
        // Find Link IDs first
        $stmt = $pdo->prepare("SELECT id FROM link WHERE trackerId = ?");
        $stmt->execute([$id]);
        $linkIds = $stmt->fetchAll(PDO::FETCH_COLUMN);

        if (!empty($linkIds)) {
            $inQuery = implode(',', array_fill(0, count($linkIds), '?'));
            $deleteClicks = $pdo->prepare("DELETE FROM click WHERE linkId IN ($inQuery)");
            $deleteClicks->execute($linkIds);
        }

        // 2. Delete Links
        $deleteLinks = $pdo->prepare("DELETE FROM link WHERE trackerId = ?");
        $deleteLinks->execute([$id]);

        // 3. Delete Tracker
        $deleteTracker = $pdo->prepare("DELETE FROM tracker WHERE id = ?");
        $deleteTracker->execute([$id]);

        $pdo->commit();
        echo json_encode(["success" => true]);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        http_response_code(500);
        echo json_encode(["error" => "Failed to delete tracker: " . $e->getMessage()]);
    }
    exit;
}
?>
