<?php
// api/live_traffic.php
// Returns latest 10 clicks for Live Traffic widget
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require '../config.php';

try {
    // Join Click -> Link -> Tracker to get Tracker Name
    // Limit 10 (Frontend only shows 5, but fetching 10 is safe)
    $stmt = $pdo->query("
        SELECT 
            c.id, 
            c.country, 
            t.name as trackerName, 
            l.network, 
            c.createdAt 
        FROM click c
        JOIN link l ON c.linkId = l.id
        LEFT JOIN tracker t ON l.trackerId = t.id
        ORDER BY c.createdAt DESC
        LIMIT 10
    ");
    
    $clicks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Map to frontend expectation
    $result = array_map(function($click) {
        return [
            'id' => $click['id'],
            'country' => $click['country'], // Country Code "ID", "US"
            'trackerId' => $click['trackerName'], // Frontend calls it trackerId or name
            'network' => $click['network'] ?? 'Unknown'
        ];
    }, $clicks);

    echo json_encode(["type" => "update", "data" => $result]);

} catch (PDOException $e) {
    // Return empty on error
    echo json_encode(["type" => "update", "data" => []]);
}
?>
