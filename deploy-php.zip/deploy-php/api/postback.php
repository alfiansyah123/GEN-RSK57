<?php
// api/postback.php
// Receives S2S postbacks from CPA Networks
// Usage: /api/postback.php?clickid={clickid}&payout={payout}&smartlink={subid}&network=NetworkName&country={geo}

require_once 'config.php';

// --- DEBUGGING START ---
// Rekam semua request yang masuk untuk cek apakah parameter diterima atau dipotong
$debugFile = 'postback_debug.log';
$entry = "=== " . date('Y-m-d H:i:s') . " ===\n";
$entry .= "IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'Unknown') . "\n";
$entry .= "Raw URI: " . ($_SERVER['REQUEST_URI'] ?? '') . "\n"; // Cek apakah # ada disini
$entry .= "GET Params: " . print_r($_GET, true) . "\n";
file_put_contents($debugFile, $entry, FILE_APPEND);
// --- DEBUGGING END ---

// Accept clickid from various params (this is the unique click identifier)
// Helper to find first non-empty param
function getFirstNonEmpty($params, $keys) {
    foreach ($keys as $key) {
        if (!empty($params[$key])) {
            return $params[$key];
        }
    }
    return null;
}

// Accept network/source - moved UP to allow specific logic based on network
$networkParam = getFirstNonEmpty($_GET, ['network', 'source', 'affiliate', 'aff']);
$networkNameValue = $networkParam ? strtolower($networkParam) : '';

// Accept clickid (note: Trafee uses 'track' instead of 'clickid', and we also check 'external_id' for Trafee)
$clickIdKeys = ['clickid', 'click_id', 'cid', 'track'];
if (strpos($networkNameValue, 'trafee') !== false) {
    $clickIdKeys[] = 'external_id';
}
$clickIdParam = getFirstNonEmpty($_GET, $clickIdKeys);

$payout = $_GET['payout'] ?? $_GET['sum'] ?? 0.00;
// Ensure payout is a valid decimal/float
if (!is_numeric($payout) || empty($payout)) {
    $payout = 0.00;
}
$currency = $_GET['currency'] ?? 'USD';
$status = $_GET['status'] ?? 'approved';
$txid = $_GET['txid'] ?? null;

// Accept SMARTLINK/TRACKER NAME (sub_id) - Check deeper keys
// s1 = Tracker Name (User Request)
$smartlinkParam = getFirstNonEmpty($_GET, ['smartlink', 'subid', 'sub_id', 'tracker', 'campaign', 's1', 's2', 's3', 's4', 'subsource', 'sub_source']);

// Accept country
$countryParam = getFirstNonEmpty($_GET, ['country', 'geo', 'country_code', 'cc']);

// Accept IP
$ipParam = getFirstNonEmpty($_GET, ['ip', 'user_ip', 'uip']);

// Accept User Agent
$uaParam = getFirstNonEmpty($_GET, ['ua', 'user_agent', 'useragent']);

// Accept traffic type
$trafficParam = getFirstNonEmpty($_GET, ['traffic', 'traffic_type', 'device']);

// Accept network/source - (Already retrieved above)
// $networkParam is already set

if (!$clickIdParam && !$smartlinkParam) {
    http_response_code(400);
    die("Error: Missing clickid or smartlink");
}

try {
    // 1. Resolve Details (Network, Country, Traffic, etc.)
    
    // Use network from param if provided, otherwise default to Unknown
    $network = $networkParam ? $networkParam : 'Unknown';
    
    // PRIORITY: Use smartlink param directly if provided (this is the tracker name!)
    $trackerName = $smartlinkParam ? $smartlinkParam : 'Unknown';
    
    // Country Logic
    $country = ($countryParam && $countryParam !== 'XX') ? strtoupper($countryParam) : null;
    
    // Fix common country code issues
    if ($country === 'UK') { $country = 'GB'; }
    if ($country === 'UKRAINE' || $country === 'UKR') { $country = 'UA'; }
    
    // IP Geolocation Fallback: If country not provided, lookup from IP
    if (empty($country) && $ipParam) {
        $geoResponse = @file_get_contents("http://ip-api.com/json/{$ipParam}?fields=countryCode");
        if ($geoResponse) {
            $geoData = json_decode($geoResponse, true);
            if (!empty($geoData['countryCode'])) {
                $country = strtoupper($geoData['countryCode']);
            }
        }
    }
    
    // Final fallback if still empty
    if (empty($country)) {
        $country = 'XX';
    }
    
    $countryName = ($country !== 'XX') ? $country : 'Unknown';

    // IP Logic
    if ($ipParam) {
        $ip = $ipParam;
    } else {
        // Fallback to headers if param is missing
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'] 
            ?? $_SERVER['HTTP_X_FORWARDED_FOR'] 
            ?? $_SERVER['HTTP_X_REAL_IP'] 
            ?? $_SERVER['REMOTE_ADDR'] 
            ?? '0.0.0.0';
        if (strpos($ip, ',') !== false) {
             $ip = trim(explode(',', $ip)[0]);
        }
    }
    
    // User Agent - from param or request header
    $userAgent = $uaParam ?? $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    // Traffic Type - from param or parse from UA
    if ($trafficParam) {
        $trafficType = strtoupper($trafficParam);
    } else {
        $trafficType = 'WAP'; // Default WAP karena mayoritas traffic CPA mobile
        $ua = strtolower($userAgent);
        if (strpos($ua, 'bot') !== false || strpos($ua, 'spider') !== false || strpos($ua, 'crawler') !== false) {
            $trafficType = 'BOT';
        } elseif (strpos($ua, 'mobile') !== false || strpos($ua, 'android') !== false || strpos($ua, 'iphone') !== false) {
            $trafficType = 'WAP';
        }
    }
    // --- CLICK DATA LOOKUP: Get Real IP/Country from Click Table ---
    // The click_id in conversions SHOULD match external_id in cuanfbpr_gencok.click
    // BUT some networks (like Trafee) send tracker_name as click_id instead of actual external_id!
    $clickLookupId = $clickIdParam; 
    $gencokDb = 'cuanfbpr_gencok';
    $clickRecord = null;
    
    if (empty($ipParam) || $country === 'XX') {
        try {
            // METHOD 1: Direct lookup by external_id (works when network sends proper click_id)
            if ($clickLookupId) {
                $stmt = $pdo->prepare("SELECT ip, country, userAgent FROM {$gencokDb}.click WHERE external_id = ? ORDER BY createdAt DESC LIMIT 1");
                $stmt->execute([$clickLookupId]);
                $clickRecord = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            if (!$clickRecord && $trackerName && $trackerName !== 'Unknown') {
                $stmt = $pdo->prepare("
                    SELECT c.ip, c.country, c.userAgent 
                    FROM {$gencokDb}.click c
                    INNER JOIN {$gencokDb}.link l ON c.linkId = l.id
                    INNER JOIN {$gencokDb}.tracker t ON l.trackerId = t.id
                    WHERE t.name = ? 
                    AND l.network = ?
                    ORDER BY c.createdAt DESC 
                    LIMIT 1
                ");
                $stmt->execute([$trackerName, $network]);
                $clickRecord = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            
            // METHOD 3: More aggressive fallback - just by tracker name
            if (!$clickRecord && $trackerName && $trackerName !== 'Unknown') {
                $stmt = $pdo->prepare("
                    SELECT c.ip, c.country, c.userAgent 
                    FROM {$gencokDb}.click c
                    INNER JOIN {$gencokDb}.link l ON c.linkId = l.id
                    INNER JOIN {$gencokDb}.tracker t ON l.trackerId = t.id
                    WHERE t.name = ?
                    ORDER BY c.createdAt DESC 
                    LIMIT 1
                ");
                $stmt->execute([$trackerName]);
                $clickRecord = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            
            // Apply found click data
            if ($clickRecord) {
                // Use stored IP if not provided by network
                if (empty($ipParam) && !empty($clickRecord['ip'])) {
                    $ip = $clickRecord['ip'];
                }
                
                // Use stored Country if current is XX
                if ($country === 'XX' && !empty($clickRecord['country']) && $clickRecord['country'] !== 'XX') {
                    $country = strtoupper($clickRecord['country']);
                    $countryName = $country;
                }
            }
        } catch (Exception $e) {
            // Silent error - click table might not be accessible
        }
    }

    // Everything is already resolved above.
    // No additional DB Lookup needed.

    // 2. Insert into Flat 'conversions' table
    // Columns: id, click_id, sub_id, network, country, country_name, traffic_type, earning, ip_address, user_agent, created_at
    // Note: User requested 'smartlink' column be renamed to 'sub_id'. We assume he creates/renames it.
    // We will use 'sub_id' in the INSERT statement. If the table still uses 'smartlink', this will fail until he runs the ALTER.
    
    // Check if sub_id passes, otherwise use trackerName or clickIdParam
    $subId = $trackerName !== 'Unknown' ? $trackerName : $clickIdParam;

    // Ensure we have a valid click_id for the database (cannot be null)
    // If clickIdParam is missing, use subId (if valid) or generate a unique ID
    $dbClickId = $clickIdParam;
    if (empty($dbClickId)) {
        $dbClickId = (!empty($subId) && $subId !== 'Unknown') ? $subId : ('gen-' . uniqid());
    }

    $stmt = $pdo->prepare("INSERT INTO conversions (click_id, sub_id, network, country, country_name, traffic_type, earning, ip_address, user_agent) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    $stmt->execute([
        $dbClickId,    // Use resolved dbClickId

        $subId,        // sub_id (mapped from tracker name or param)
        $network,
        // Final Safety Check: Ensure Country is mapped correctly (e.g. if DB had 'UK')
        ($country === 'UK' ? 'GB' : ($country === 'UKRAINE' ? 'UA' : $country)),
        $country !== 'XX' ? $country : 'Unknown', // Country Name
        $trafficType,
        $payout,
        $ip,
        $userAgent
    ]);

    // 3. Update 'daily_reports' (Optional but good for aggregation)
    $today = date('Y-m-d', strtotime('+7 hours'));
    $stmt = $pdo->prepare("INSERT INTO daily_reports (date, smartlink, network, leads, payout) 
                           VALUES (?, ?, ?, 1, ?) 
                           ON DUPLICATE KEY UPDATE leads = leads + 1, payout = payout + ?");
    // Note: daily_reports might still use 'smartlink' column name in his DB based on db.sql
    // We'll stick to 'smartlink' for daily_reports for now unless he asked to change that too.
    $stmt->execute([$today, $subId, $network, $payout, $payout]);

    // 4. CROSS-DATABASE UPDATE (CRITICAL FOR REPORTS)
    // Update tabel 'link' di database `ccpxengi_linkdb` 
    // karena Reports page membaca data dari database tersebut.
    
    // Nama Database Link (sesuai info user: ccpxengi_gencok)
    $linkDbName = 'cuanfbpr_gencok'; 

    try {
        // Update by Tracker Name + Network
        $stmt = $pdo->prepare("UPDATE {$linkDbName}.link l
                               INNER JOIN {$linkDbName}.tracker t ON l.trackerId = t.id
                               SET l.leadCount = l.leadCount + 1, 
                                   l.totalPayout = l.totalPayout + ?
                               WHERE t.name = ? AND l.network = ?");
        $stmt->execute([$payout, $subId, $network]);
        
        // Fallback: Update by Slug + Network (jika tracker name user input manual beda)
        if ($stmt->rowCount() == 0) {
             $stmt = $pdo->prepare("UPDATE {$linkDbName}.link 
                                   SET leadCount = leadCount + 1, 
                                       totalPayout = totalPayout + ?
                                   WHERE slug = ? AND network = ?");
             $stmt->execute([$payout, $subId, $network]);
        }
    } catch (Exception $e) {
        // Silent error logic if cross-db access fails
    }

    http_response_code(200);
    echo "OK: Conversion recorded. SubID: $subId, Link table updated.";

} catch (PDOException $e) {
    http_response_code(500);
    echo "Error: " . $e->getMessage();
}
?>
