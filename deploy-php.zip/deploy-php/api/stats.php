<?php
// api/stats.php
// Handles /api/reports

$method = $_SERVER['REQUEST_METHOD'];
if ($method !== 'GET') {
    http_response_code(405);
    exit;
}

// Basic aggregation or Detailed Logs
// GET /api/reports?mode=conversions&startDate=...&endDate=...

$mode = $_GET['mode'] ?? 'stats'; // 'stats' (default) or 'conversions'
$startDate = $_GET['startDate'] ?? date('Y-m-d', strtotime('-30 days'));
$endDate = $_GET['endDate'] ?? date('Y-m-d', strtotime('+1 day'));

/*
  Node.js logic (simplified):
  - Total Clicks
  - Total Conversions (if any)
  - Group by variable
*/

try {
    if ($mode === 'conversions') {
        // Detailed Conversion Logs
        // Join Conversion -> Click -> Link -> Tracker
        // Note: Conversion table usually has clickId.
        
        // Adjust Start/End date for timezone if needed, assuming user input is simplified date YYYY-MM-DD
        // We will query based on Conversion.createdAt
        
        // Helper to get simple field
        // Since we now use a FLAT table 'conversions' with correct columns
        $sql = "SELECT 
                    id,
                    earning,
                    click_id as clickId,
                    created_at,
                    ip_address as ipAddress,
                    country,
                    user_agent as userAgent,
                    network,
                    traffic_type as traffic,
                    sub_id as smartlink
                FROM conversions 
                WHERE DATE(DATE_SUB(created_at, INTERVAL 7 HOUR)) >= ? 
                  AND DATE(DATE_SUB(created_at, INTERVAL 7 HOUR)) <= ?
                ORDER BY created_at DESC LIMIT 500";
                
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$startDate, $endDate]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Post-processing is minimal now as data is already in table
        foreach ($rows as &$row) {
             // Derive Traffic if missing (though postback fills it now)
             if (empty($row['traffic'])) {
                 $ua = strtolower($row['userAgent'] ?? '');
                 if (strpos($ua, 'bot') !== false) $row['traffic'] = 'BOT';
                 elseif (strpos($ua, 'mobile') !== false) $row['traffic'] = 'WAP';
                 else $row['traffic'] = 'WEB';
             }

             // Format flag
            if (!empty($row['country']) && $row['country'] !== 'XX') {
                $row['flag'] = 'https://flagcdn.com/w40/' . strtolower($row['country']) . '.png';
            } else {
                $row['flag'] = 'https://flagcdn.com/w40/un.png';
            }
        }
        
        echo json_encode(['data' => $rows]);
        return; // Early return for this mode
        
    } else {
        // COMPLEX AGGREGATION FOR ACCURATE REPORTS
        // Problem: 'link' table stores LIFETIME leads/clicks. 'conversions' table stores REALTIME events.
        // Solution: 
        // 1. Get Real Leads/Revenue from `ccpxengi_report.conversions` (Filtered by Date) -> ACCURATE LEADS
        // 2. Get Clicks from `link` table (Note: This is LIFETIME clicks, we don't have daily clicks table yet)
        
        $convDb = 'cpa_dashboard';
        
        // 1. Get Accurate Leads & Revenue from Conversions DB
        $sqlConv = "SELECT sub_id as trackerName, network, 
                           COUNT(*) as distinctLeads, 
                           SUM(earning) as distinctRevenue
                    FROM {$convDb}.conversions 
                    WHERE DATE(created_at) >= ? 
                      AND DATE(created_at) <= ?
                    GROUP BY sub_id, network";
                    
        $stmt = $pdo->prepare($sqlConv);
        $stmt->execute([$startDate, $endDate]);
        $convRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Index conversion data by key "TrackerName|Network"
        $convMap = [];
        foreach ($convRows as $row) {
            $key = strtolower($row['trackerName']) . '|' . strtolower($row['network']);
            $convMap[$key] = [
                'leads' => (int)$row['distinctLeads'],
                'revenue' => (float)$row['distinctRevenue']
            ];
        }

        // 2. Get Clicks from `click` Table (ACCURATE DAILY CLICKS)
        // Join with Link and Tracker to get names
        // Filter by Date from `click.createdAt`
        
        $sqlLink = "SELECT t.name as trackerName, l.network, 
                           COUNT(c.id) as totalClicks
                    FROM click c
                    JOIN link l ON c.linkId = l.id
                    JOIN tracker t ON l.trackerId = t.id
                    WHERE DATE(c.createdAt) >= ? 
                      AND DATE(c.createdAt) <= ?
                    GROUP BY t.name, l.network";
                    
        $stmt = $pdo->prepare($sqlLink);
        $stmt->execute([$startDate, $endDate]);
        $linkRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 3. Merge Data
        $finalData = [];
        $processedKeys = [];

        // First pass: Process Links
        foreach ($linkRows as $row) {
             $tName = $row['trackerName'] ?? 'Unknown';
             $net = $row['network'] ?? 'Unknown';
             $key = strtolower($tName) . '|' . strtolower($net);
             
             // Get leads/rev from map
             $stats = $convMap[$key] ?? ['leads' => 0, 'revenue' => 0];
             
             // Filter: Show ONLY if there is activity (Clicks OR Leads)
             if ($row['totalClicks'] == 0 && $stats['leads'] == 0) continue;

             $finalData[$key] = [
                 'trackerName' => $tName,
                 'network' => $net,
                 'clicks' => (int)$row['totalClicks'],
                 'leads' => $stats['leads'],
                 'revenue' => $stats['revenue']
             ];
             $processedKeys[$key] = true;
        }

        // Second pass: Process Orphan Conversions (Leads that have no matching link in table?? unlikely but possible)
        foreach ($convMap as $key => $stats) {
            if (!isset($processedKeys[$key])) {
                list($tName, $net) = explode('|', $key);
                // Beautify name if possible
                $finalData[$key] = [
                    'trackerName' => ucfirst($tName), // weak fallback formatting
                    'network' => ucfirst($net),
                    'clicks' => 0, // No matching link found
                    'leads' => $stats['leads'],
                    'revenue' => $stats['revenue']
                ];
            }
        }

        // Format for Frontend
        $data = [];
        $counter = 1;
        foreach ($finalData as $row) {
            $clicks = $row['clicks'];
            $leads = $row['leads'];
            $revenue = $row['revenue'];
            
            // Filter User Request: "POKOK YA MINIMAL 1 CLICK BARU TAMPIL"
            // (Unless there are leads, then show it too)
            if ($clicks === 0 && $leads === 0) continue;

            $cr = $clicks > 0 ? ($leads / $clicks) * 100 : 0;
            
            $data[] = [
                'id' => $counter++,
                'smartlink' => $row['trackerName'],
                'network' => $row['network'],
                'clicks' => $clicks,
                'leads' => $leads,
                'cr' => $cr,
                'payouts' => $revenue
            ];
        }
        
        echo json_encode(['data' => $data]);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["error" => $e->getMessage()]);
}
?>
